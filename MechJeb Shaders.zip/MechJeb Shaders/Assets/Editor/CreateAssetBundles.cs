﻿using UnityEditor;
using System;
using System.IO;

public class CreateAssetBundles
{
	[MenuItem ("Assets/Build AssetBundles")]
	static void BuildAllAssetBundles ()
	{
		foreach (BuildTarget target in new BuildTarget[] {
			BuildTarget.StandaloneWindows, BuildTarget.StandaloneWindows64, 
			BuildTarget.StandaloneLinux, BuildTarget.StandaloneLinux64, BuildTarget.StandaloneLinuxUniversal,
			BuildTarget.StandaloneOSXIntel, BuildTarget.StandaloneOSXIntel64, BuildTarget.StandaloneOSXUniversal
		}) {
			string path = Path.Combine ("Assets/AssetBundles", target.ToString ());
			Directory.CreateDirectory (path);
			BuildPipeline.BuildAssetBundles (path, BuildAssetBundleOptions.UncompressedAssetBundle, target);
		}
	}
}